package giftcardvouchers;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class GiftcardVoucherTestCreation {

	
	
	WebDriver driver;
	JavascriptExecutor executor;
	


	@FindBy (how=How.XPATH, using="//span[contains(text(),'Vouchers & Gift cards')]") WebElement GiftcardVocher ;
	@FindBy (how=How.XPATH, using="//h3[contains(text(),'My Vouchers & Gift Cards')]") WebElement MyGiftcardVocherpage ;
	@FindBy (how=How.XPATH, using="//button[contains(text(),'+ Add New Vouchers & Gift Cards')]") WebElement AddNewGiftcard ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Vouchers')]") WebElement VoucherKPI ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Gift Cards')]") WebElement GiftcardKPI ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Totals')]") WebElement TotalKPI ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[4]/div[1]/div[1]/input[1]") WebElement searchfield ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[4]/div[1]/div[1]/div[1]/button[1]/img[1]") WebElement searchclose ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Filter by :')]") WebElement filterby ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Sort by :')]") WebElement sortby ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]") WebElement filterbyclick ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]") WebElement sortbyclick ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Expired')]\"") WebElement filterExpired ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'All')]\"") WebElement filterALL ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Active')]\"") WebElement filterActive ;
	
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Created')]") WebElement SortCreated ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Updated')]") WebElement SortUpdated ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Expiry Date')]") WebElement SortExpiryDate ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Total Amount')]") WebElement SortTotalAmount ;
	
	@FindBy (how=How.XPATH, using="Total Amount") WebElement Type ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[3]/small[1]") WebElement supplier ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[4]/small[1]") WebElement Totalamount ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[5]/small[1]") WebElement UsedAmount ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[6]/small[1]") WebElement Remainingamount ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[7]/small[1]") WebElement ExpiresON ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[8]/small[1]") WebElement Reminder ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[8]/p[1]/label[1]/div[1]") WebElement ReminderOFF ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[2]/div[1]/div[1]/div[1]/div[8]/p[1]/label[1]/div[1]") WebElement ReminderON ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[9]/span[1]/img[1]") WebElement EditIcon ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/span[1]/div[1]/div[1]/div[1]/div[9]/span[1]/img[2]") WebElement DeleteIcon ;
	
	
	
	//Add New GiftCard//
	@FindBy (how=How.XPATH, using="//h3[contains(text(),'Add a New Voucher & Gift card')]") WebElement AddNewGiftVoucherPage ;
	@FindBy (how=How.XPATH, using="//label[contains(text(),'Supplier')]") WebElement AddSupplier ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[1]/span[1]/a[1]/p[1]") WebElement BacktoMyGiftVoucherPage ;
	
	
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]") WebElement AddType ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]") WebElement TypeField ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Gift Card')]") WebElement GiftcardSelect ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]") WebElement SupplierField ;
	@FindBy (how=How.XPATH, using="//div[contains(text(),'Zomato')]") WebElement SupplierSelect ;
	@FindBy (how=How.XPATH, using="//label[contains(text(),'Total Amount')]") WebElement AddTotalAmount ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]") WebElement TotalAmountField ;
	@FindBy (how=How.XPATH, using="//label[contains(text(),'Used Amount ( optional )')]") WebElement AddUsedAmount ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/input[1]") WebElement UsedAmountField ;
	@FindBy (how=How.XPATH, using="//label[contains(text(),'Expiry Date')]") WebElement AddExpiryDate ;
	@FindBy (how=How.XPATH, using="//body/div[@id='root']/div[2]/div[2]/div[1]/form[1]/div[2]/div[1]/div[3]/div[1]/div[1]/input[1]") WebElement ExpiryDateField ;
	@FindBy (how=How.XPATH, using="//p[contains(text(),'Reminder on')]") WebElement ReminderONStatus ;
	@FindBy (how=How.XPATH, using="//input[@id='custom-switch']") WebElement AddReminderOFF ;
	@FindBy (how=How.XPATH, using="//span[contains(text(),'Add Gift Card')]") WebElement AddGiftCardButton ;
	@FindBy (how=How.XPATH, using="//span[contains(text(),'Add Voucher')]") WebElement AddVoucherButton ;
	
	
	

	GiftcardVoucherTestCreation(WebDriver driver)
	 {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
		
		 this.executor = (JavascriptExecutor) this.driver; 
	 }	

	public void test1() throws Exception
	{
		Thread.sleep(2000);
		GiftcardVocher.click();
		Thread.sleep(1000);
		MyGiftcardVocherpage.isDisplayed();
	}
	

	public void test2() throws Exception
	{
		Thread.sleep(2000);
		GiftcardVocher.click();
		Thread.sleep(1000);
		MyGiftcardVocherpage.isDisplayed();
		
		
		
		
		
		
		
		
	}
}
